# Metode yang dipanggil dari JavaScript (WebView) tidak boleh dihapus/diganti nama.
-keepclassmembers class com.madz.web.** {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.madz.web.MainActivity$Bridge { *; }
-keep class com.madz.web.OverlayService$OBridge { *; }
# Komponen yang dirujuk lewat nama di manifest (alias ikon, receiver, service).
-keep class com.madz.web.BootReceiver
-keep class com.madz.web.NotifListener
-keep class com.madz.web.OverlayService
