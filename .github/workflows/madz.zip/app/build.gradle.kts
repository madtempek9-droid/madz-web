plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.madz.web"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.madz.web"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"
    }
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    signingConfigs {
        // Isi lewat ~/.gradle/gradle.properties atau variabel lingkungan; jangan simpan di repo.
        val ks = (project.findProperty("MADZ_KEYSTORE") as String?) ?: System.getenv("MADZ_KEYSTORE")
        if (ks != null) {
            create("release") {
                storeFile = file(ks)
                storePassword = (project.findProperty("MADZ_STORE_PASS") as String?) ?: System.getenv("MADZ_STORE_PASS")
                keyAlias = (project.findProperty("MADZ_KEY_ALIAS") as String?) ?: System.getenv("MADZ_KEY_ALIAS")
                keyPassword = (project.findProperty("MADZ_KEY_PASS") as String?) ?: System.getenv("MADZ_KEY_PASS")
            }
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.findByName("release") ?: signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("androidx.core:core-ktx:1.13.1") }
