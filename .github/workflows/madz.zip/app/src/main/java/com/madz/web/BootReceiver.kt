package com.madz.web

import android.util.Log
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED) return
        val p = c.getSharedPreferences("madz", Context.MODE_PRIVATE)
        if (p.getBoolean("auto", false) && p.getBoolean("wasOn", false) && Settings.canDrawOverlays(c)) {
            try { c.startForegroundService(Intent(c, OverlayService::class.java)) } catch (e: Exception) { Log.w("MADZ", "BootReceiver", e) }
        }
    }
}
