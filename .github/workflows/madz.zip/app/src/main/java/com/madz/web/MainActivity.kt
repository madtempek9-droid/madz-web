package com.madz.web

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import org.json.JSONArray
import org.json.JSONObject
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private val ids = listOf("overlay", "notif_read", "notif_post", "bluetooth", "photos", "battery")

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, u: String?) { report() }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                w: WebView?, cb: ValueCallback<Array<Uri>>?, p: FileChooserParams?
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try {
                    startActivityForResult(p!!.createIntent(), 1); true
                } catch (e: Exception) { fileCb = null; false }
            }
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        if (r == 1) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(c, d))
            fileCb = null
        }
    }

    override fun onResume() { super.onResume(); if (::web.isInitialized) report() }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, g: IntArray) {
        super.onRequestPermissionsResult(code, p, g); report()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { super.onBackPressed() }

    private fun appInfo() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    private fun has(id: String): Boolean = when (id) {
        "overlay" -> Settings.canDrawOverlays(this)
        "notif_read" -> NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
        "notif_post" -> NotificationManagerCompat.from(this).areNotificationsEnabled()
        "battery" -> (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
        "bluetooth" -> Build.VERSION.SDK_INT < 31 ||
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        else -> true
    }

    private fun report() {
        for (id in ids)
            web.evaluateJavascript("window.onPermissionResult&&onPermissionResult('$id',${has(id)})", null)
    }

    inner class Bridge {
        @JavascriptInterface
        fun openUrl(url: String) = runOnUiThread {
            if (!url.startsWith("https://wa.me/")) return@runOnUiThread
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
            catch (e: Exception) { Toast.makeText(this@MainActivity, "WhatsApp tidak ditemukan", Toast.LENGTH_SHORT).show() }
        }

        @JavascriptInterface
        fun getApps(): String {
            val pm = packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val arr = JSONArray()
            pm.queryIntentActivities(intent, 0)
                .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
                .distinctBy { it.first }
                .filter { it.first != packageName }
                .sortedBy { it.second.lowercase() }
                .forEach { arr.put(JSONObject().put("p", it.first).put("n", it.second)) }
            return arr.toString()
        }

        @JavascriptInterface
        fun setIcon(name: String) {
            val all = listOf("Default", "Blue", "Red", "Green", "Purple", "Orange")
            if (name !in all) return
            runOnUiThread {
                fun set(n: String, on: Boolean) = packageManager.setComponentEnabledSetting(
                    ComponentName(packageName, "com.madz.web.Icon$n"),
                    if (on) PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                    PackageManager.DONT_KILL_APP
                )
                set(name, true)
                all.filter { it != name }.forEach { set(it, false) }
            }
        }

        @JavascriptInterface
        fun setAutostart(on: Boolean) {
            getSharedPreferences("madz", MODE_PRIVATE).edit().putBoolean("auto", on).apply()
        }

        @JavascriptInterface
        fun copy(text: String) = runOnUiThread {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("madz", text))
            Toast.makeText(this@MainActivity, "Disalin", Toast.LENGTH_SHORT).show()
        }

        @JavascriptInterface
        fun live(json: String) = runOnUiThread {
            val svc = OverlayService.inst
            if (svc == null) Toast.makeText(this@MainActivity, "Nyalakan overlay dulu", Toast.LENGTH_SHORT).show()
            else svc.liveCmd(json)
        }

        @JavascriptInterface
        fun requestPermission(id: String) = runOnUiThread {
            when (id) {
                "overlay" -> startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                "notif_read" -> try {
                    if (Build.VERSION.SDK_INT >= 30)
                        startActivity(
                            Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS).putExtra(
                                Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME,
                                ComponentName(this@MainActivity, NotifListener::class.java).flattenToString()
                            )
                        )
                    else startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                } catch (e: Exception) { appInfo() }
                "bluetooth" -> {
                    if (Build.VERSION.SDK_INT >= 31)
                        requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 3)
                    else Unit
                }
                "appinfo" -> appInfo()
                "notif_post" ->
                    if (Build.VERSION.SDK_INT >= 33)
                        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
                    else
                        startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
                "battery" -> startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            }
        }

        @JavascriptInterface
        fun showOverlay(json: String) = runOnUiThread {
            if (!Settings.canDrawOverlays(this@MainActivity)) {
                Toast.makeText(this@MainActivity, "Izinkan 'Tampil di atas aplikasi lain' dulu", Toast.LENGTH_LONG).show()
                return@runOnUiThread
            }
            OverlayService.config = json
            getSharedPreferences("madz", MODE_PRIVATE).edit().putString("cfg", json).putBoolean("wasOn", true).apply()
            val i = Intent(this@MainActivity, OverlayService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        }

        @JavascriptInterface
        fun hideOverlay() = runOnUiThread {
            getSharedPreferences("madz", MODE_PRIVATE).edit().putBoolean("wasOn", false).apply()
            stopService(Intent(this@MainActivity, OverlayService::class.java))
        }
    }
}
