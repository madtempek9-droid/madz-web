package com.madz.web

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import org.json.JSONObject

/** Streak musik harian & hitungan buka HP. Hanya angka lokal di SharedPreferences, tidak ada konten yang disimpan. */
object Streak {
    private const val NEED_SEC = 120

    private fun day(offset: Int): String {
        val c = Calendar.getInstance()
        c.add(Calendar.DAY_OF_YEAR, offset)
        return SimpleDateFormat("yyyyMMdd", Locale.US).format(c.time)
    }

    private fun json(n: Int, today: Boolean, best: Int, secs: Int, up: Boolean) =
        JSONObject().put("n", n).put("today", today).put("best", best).put("secs", secs).put("need", NEED_SEC).put("up", up).toString()

    /** Dipanggil tiap beberapa detik saat musik diputar. up=true saat hari ini baru saja terhitung. */
    @Synchronized
    fun add(ctx: Context, sec: Int): String {
        val p = ctx.getSharedPreferences("madz", Context.MODE_PRIVATE)
        val today = day(0)
        val yest = day(-1)
        var secs = if (p.getString("sk_day", "") == today) p.getInt("sk_sec", 0) else 0
        secs += sec.coerceIn(0, 60)
        var n = p.getInt("sk_n", 0)
        var last = p.getString("sk_last", "") ?: ""
        var up = false
        if (last != today && secs >= NEED_SEC) {
            n = if (last == yest) n + 1 else 1
            last = today
            up = true
        }
        val best = maxOf(p.getInt("sk_best", 0), n)
        p.edit().putString("sk_day", today).putInt("sk_sec", secs).putInt("sk_n", n)
            .putString("sk_last", last).putInt("sk_best", best).apply()
        return json(if (last == today || last == yest) n else 0, last == today, best, secs, up)
    }

    @Synchronized
    fun get(ctx: Context): String {
        val p = ctx.getSharedPreferences("madz", Context.MODE_PRIVATE)
        val last = p.getString("sk_last", "") ?: ""
        val n = if (last == day(0) || last == day(-1)) p.getInt("sk_n", 0) else 0
        val secs = if (p.getString("sk_day", "") == day(0)) p.getInt("sk_sec", 0) else 0
        return json(n, last == day(0), p.getInt("sk_best", 0), secs, false)
    }

    @Synchronized
    fun unlockAdd(ctx: Context): Int {
        val p = ctx.getSharedPreferences("madz", Context.MODE_PRIVATE)
        val today = day(0)
        val n = (if (p.getString("ul_day", "") == today) p.getInt("ul_n", 0) else 0) + 1
        p.edit().putString("ul_day", today).putInt("ul_n", n).apply()
        return n
    }

    @Synchronized
    fun unlockGet(ctx: Context): Int {
        val p = ctx.getSharedPreferences("madz", Context.MODE_PRIVATE)
        return if (p.getString("ul_day", "") == day(0)) p.getInt("ul_n", 0) else 0
    }
}
