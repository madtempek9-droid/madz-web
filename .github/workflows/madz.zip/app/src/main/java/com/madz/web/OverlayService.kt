package com.madz.web

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject

class OverlayService : Service() {
    companion object {
        var config = "{}"
        var inst: OverlayService? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var view: WebView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var cfg = JSONObject()
    private var d = 1f

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        startFg()
        inst = this
        cfg = try { JSONObject(config) } catch (e: Exception) { JSONObject() }
        removeView()
        addView()
        return START_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        val b: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("ov", "Overlay", NotificationManager.IMPORTANCE_MIN))
            b = Notification.Builder(this, "ov")
        } else b = Notification.Builder(this)
        val n = b.setContentTitle("MADZ WEB aktif").setSmallIcon(android.R.drawable.ic_dialog_info).build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun addView() {
        d = resources.displayMetrics.density
        val L = cfg.optJSONObject("layout") ?: JSONObject()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val wv = WebView(this)
        wv.setBackgroundColor(Color.TRANSPARENT)
        wv.settings.javaScriptEnabled = true
        wv.addJavascriptInterface(OBridge(), "Android")
        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, u: String?) {
                v?.evaluateJavascript("setConfig(${JSONObject.quote(cfg.toString())})", null)
                NotifListener.inst?.refreshMusic()
            }
        }
        wv.loadUrl("file:///android_asset/overlay.html")
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val p = WindowManager.LayoutParams(
            ((L.optInt("w", 126) + 16) * d).toInt(), (52 * d).toInt(), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        p.x = (L.optInt("x", 0) * d).toInt()
        p.y = ((L.optInt("y", 12) - 8).coerceAtLeast(0) * d).toInt()
        lp = p
        view = wv
        wm?.addView(wv, p)
    }

    private fun removeView() {
        try { view?.let { wm?.removeView(it); it.destroy() } } catch (e: Exception) {}
        view = null
    }

    fun notify(title: String, text: String) {
        main.post {
            view?.evaluateJavascript(
                "notify(${JSONObject.quote(title)},${JSONObject.quote(text)})", null
            )
        }
    }

    fun setMusic(t: String, a: String, art: String) {
        main.post {
            view?.evaluateJavascript(
                "setMusic(${JSONObject.quote(t)},${JSONObject.quote(a)},${JSONObject.quote(art)})", null
            )
        }
    }

    fun stopMusic() {
        main.post { view?.evaluateJavascript("stopMusic()", null) }
    }

    override fun onDestroy() {
        removeView()
        inst = null
        super.onDestroy()
    }

    inner class OBridge {
        @JavascriptInterface
        fun resize(open: Boolean) {
            main.post {
                val L = cfg.optJSONObject("layout") ?: JSONObject()
                val sw = resources.displayMetrics.widthPixels
                val p = lp ?: return@post
                if (open) {
                    p.width = minOf(((L.optInt("e", 320) + 16) * d).toInt(), sw)
                    p.height = (100 * d).toInt()
                } else {
                    p.width = ((L.optInt("w", 126) + 16) * d).toInt()
                    p.height = (52 * d).toInt()
                }
                try { view?.let { wm?.updateViewLayout(it, p) } } catch (e: Exception) {}
            }
        }
    }
}
