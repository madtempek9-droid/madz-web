package com.madz.web

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject

class OverlayService : Service() {
    companion object {
        var config = "{}"
        var inst: OverlayService? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var view: WebView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var cfg = JSONObject()
    private var d = 1f
    private var rcvOn = false

    private fun q(s: String) = JSONObject.quote(s)
    private fun js(code: String) { main.post { view?.evaluateJavascript(code, null) } }

    fun sys(cat: String, a: String, b: String, ring: Int? = null) =
        js("sysEvent(${q(cat)},${q(a)},${q(b)},${ring ?: "null"})")

    private fun batt(): Int {
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val l = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val s = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        return if (l < 0 || s <= 0) 0 else l * 100 / s
    }

    private val rcv = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                BluetoothAdapter.ACTION_STATE_CHANGED -> {
                    val st = i.getIntExtra(BluetoothAdapter.EXTRA_STATE, -1)
                    if (st == BluetoothAdapter.STATE_ON) sys("bt", "Bluetooth", "Dinyalakan")
                    else if (st == BluetoothAdapter.STATE_OFF) sys("bt", "Bluetooth", "Dimatikan")
                }
                BluetoothDevice.ACTION_ACL_CONNECTED, BluetoothDevice.ACTION_ACL_DISCONNECTED -> {
                    val on = i.action == BluetoothDevice.ACTION_ACL_CONNECTED
                    val dev: BluetoothDevice? =
                        if (Build.VERSION.SDK_INT >= 33)
                            i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                        else @Suppress("DEPRECATION") i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    val name = (try { dev?.name } catch (e: SecurityException) { null }) ?: "Perangkat Bluetooth"
                    sys("bt", name, if (on) "Terhubung" else "Terputus")
                }
                Intent.ACTION_POWER_CONNECTED -> { val l = batt(); sys("chg", "Mengisi daya", "$l%", l) }
                Intent.ACTION_POWER_DISCONNECTED -> { val l = batt(); sys("chg", "Charger dicabut", "$l%", l) }
                Intent.ACTION_BATTERY_LOW -> { val l = batt(); sys("chg", "Baterai lemah", "$l%", l) }
                AudioManager.RINGER_MODE_CHANGED_ACTION -> {
                    val m = (getSystemService(Context.AUDIO_SERVICE) as AudioManager).ringerMode
                    sys("mode", "Mode suara", when (m) {
                        AudioManager.RINGER_MODE_SILENT -> "Senyap"
                        AudioManager.RINGER_MODE_VIBRATE -> "Getar"
                        else -> "Dering"
                    })
                }
                NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED -> {
                    val f = getSystemService(NotificationManager::class.java).currentInterruptionFilter
                    sys("mode", "Jangan ganggu", if (f == NotificationManager.INTERRUPTION_FILTER_ALL) "Mati" else "Aktif")
                }
                WifiManager.WIFI_STATE_CHANGED_ACTION -> {
                    val st = i.getIntExtra(WifiManager.EXTRA_WIFI_STATE, -1)
                    if (st == WifiManager.WIFI_STATE_ENABLED) sys("mode", "Wi-Fi", "Dinyalakan")
                    else if (st == WifiManager.WIFI_STATE_DISABLED) sys("mode", "Wi-Fi", "Dimatikan")
                }
                Intent.ACTION_AIRPLANE_MODE_CHANGED ->
                    sys("mode", "Mode pesawat", if (i.getBooleanExtra("state", false)) "Aktif" else "Mati")
                "android.media.VOLUME_CHANGED_ACTION" -> {
                    val type = i.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1)
                    val v = i.getIntExtra("android.media.EXTRA_VOLUME_STREAM_VALUE", -1)
                    if (type == AudioManager.STREAM_MUSIC && v >= 0) {
                        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                        val mx = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                        val p = v * 100 / mx
                        sys("vol", "Volume", "$p%", p)
                    }
                }
            }
        }
    }

    private fun registerAll() {
        if (rcvOn) return
        val f = IntentFilter().apply {
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(Intent.ACTION_BATTERY_LOW)
            addAction(AudioManager.RINGER_MODE_CHANGED_ACTION)
            addAction(NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED)
            addAction(WifiManager.WIFI_STATE_CHANGED_ACTION)
            addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED)
            addAction("android.media.VOLUME_CHANGED_ACTION")
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(rcv, f, Context.RECEIVER_EXPORTED)
        else registerReceiver(rcv, f)
        rcvOn = true
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        startFg()
        inst = this
        registerAll()
        cfg = try { JSONObject(config) } catch (e: Exception) { JSONObject() }
        removeView()
        addView()
        return START_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ov", "Overlay", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "ov")
            .setContentTitle("MADZ WEB aktif")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun addView() {
        d = resources.displayMetrics.density
        val L = cfg.optJSONObject("layout") ?: JSONObject()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val wv = WebView(this)
        wv.setBackgroundColor(Color.TRANSPARENT)
        wv.settings.javaScriptEnabled = true
        wv.addJavascriptInterface(OBridge(), "Android")
        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, u: String?) {
                v?.evaluateJavascript("setConfig(${JSONObject.quote(cfg.toString())})", null)
                NotifListener.inst?.refreshMusic()
            }
        }
        wv.loadUrl("file:///android_asset/overlay.html")
        val p = WindowManager.LayoutParams(
            ((L.optInt("w", 126) + 16) * d).toInt(), (52 * d).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        p.x = (L.optInt("x", 0) * d).toInt()
        p.y = ((L.optInt("y", 12) - 8).coerceAtLeast(0) * d).toInt()
        lp = p
        view = wv
        wm?.addView(wv, p)
    }

    private fun removeView() {
        try { view?.let { wm?.removeView(it); it.destroy() } } catch (e: Exception) {}
        view = null
    }

    /* dipanggil oleh NotifListener & MainActivity */
    fun notify(title: String, text: String, icon: String, hasKey: Boolean) =
        js("notify(${q(title)},${q(text)},${q(icon)},$hasKey)")

    fun call(name: String, state: String, icon: String) =
        js("callShow(${q(name)},${q(state)},${q(icon)})")

    fun callEnd() = js("callEnd()")
    fun nav(t: String, s: String) = js("navShow(${q(t)},${q(s)})")
    fun navEnd() = js("navEnd()")
    fun liveCmd(json: String) = js("liveCmd(${q(json)})")

    fun setMusic(t: String, a: String, art: String, playing: Boolean, pos: Long, dur: Long, color: String) =
        js("setMusic(${q(t)},${q(a)},${q(art)},$playing,$pos,$dur,${q(color)})")

    fun stopMusic() = js("stopMusic()")

    override fun onDestroy() {
        try { unregisterReceiver(rcv) } catch (e: Exception) {}
        rcvOn = false
        removeView()
        inst = null
        super.onDestroy()
    }

    inner class OBridge {
        @JavascriptInterface
        fun resize(open: Boolean, w: Int) {
            main.post {
                val L = cfg.optJSONObject("layout") ?: JSONObject()
                val sw = resources.displayMetrics.widthPixels
                val p = lp ?: return@post
                if (open) {
                    p.width = minOf(((L.optInt("e", 320) + 16) * d).toInt(), sw)
                    p.height = (100 * d).toInt()
                } else {
                    p.width = (w * d).toInt()
                    p.height = (52 * d).toInt()
                }
                try { view?.let { wm?.updateViewLayout(it, p) } } catch (e: Exception) {}
            }
        }

        @JavascriptInterface
        fun media(cmd: String) { NotifListener.inst?.mediaCmd(cmd) }

        @JavascriptInterface
        fun haptic(k: Int) {
            main.post {
                view?.performHapticFeedback(
                    if (k == 1) HapticFeedbackConstants.LONG_PRESS else HapticFeedbackConstants.CLOCK_TICK
                )
            }
        }

        @JavascriptInterface
        fun notifOpen() { NotifListener.inst?.openLast() }

        @JavascriptInterface
        fun notifDismiss() { NotifListener.inst?.dismissLast() }

        @JavascriptInterface
        fun callAction(kind: String) { NotifListener.inst?.callAction(kind) }
    }
}
