package com.madz.web

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import java.util.Calendar
import org.json.JSONObject

class OverlayService : Service() {
    companion object {
        var config = "{}"
        var inst: OverlayService? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var view: WebView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var cfg = JSONObject()
    private var d = 1f
    private var rcvOn = false
    private var lang = "id"
    private var blocked: Set<String> = emptySet()
    private var quietOn = false
    private var qFrom = 0
    private var qTo = 0
    private var hideLand = true
    private var callActive = false

    private fun t(id: String, en: String) = if (lang == "en") en else id
    private var watcher: PrivacyWatcher? = null
    private var audioViz: AudioViz? = null
    private val battTick = object : Runnable {
        override fun run() {
            pushBatt()
            main.postDelayed(this, 30000)
        }
    }
    private fun q(s: String) = JSONObject.quote(s)
    private fun js(code: String) { main.post { view?.evaluateJavascript(code, null) } }

    fun sys(cat: String, a: String, b: String, ring: Int? = null) =
        js("sysEvent(${q(cat)},${q(a)},${q(b)},${ring ?: "null"})")

    private fun battLevel(): Int {
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val l = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val s = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        return if (l < 0 || s <= 0) 0 else Math.round(l * 100f / s)
    }

    private fun pushBatt() {
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
        val l = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val s = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val st = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val chg = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        if (l >= 0 && s > 0) js("setBatt(${Math.round(l * 100f / s)},$chg)")
    }

    private val rcv = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val on = t("Dinyalakan", "On")
            val off = t("Dimatikan", "Off")
            when (i.action) {
                BluetoothAdapter.ACTION_STATE_CHANGED -> {
                    val st = i.getIntExtra(BluetoothAdapter.EXTRA_STATE, -1)
                    if (st == BluetoothAdapter.STATE_ON) sys("bt", "Bluetooth", on)
                    else if (st == BluetoothAdapter.STATE_OFF) sys("bt", "Bluetooth", off)
                }
                BluetoothDevice.ACTION_ACL_CONNECTED, BluetoothDevice.ACTION_ACL_DISCONNECTED -> {
                    val conn = i.action == BluetoothDevice.ACTION_ACL_CONNECTED
                    val dev: BluetoothDevice? =
                        if (Build.VERSION.SDK_INT >= 33)
                            i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                        else @Suppress("DEPRECATION") i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    val name = (try { dev?.name } catch (e: SecurityException) { null })
                        ?: t("Perangkat Bluetooth", "Bluetooth device")
                    sys("bt", name, if (conn) t("Terhubung", "Connected") else t("Terputus", "Disconnected"))
                }
                Intent.ACTION_POWER_CONNECTED -> { val l = battLevel(); sys("chg", t("Mengisi daya", "Charging"), "$l%", l) }
                Intent.ACTION_POWER_DISCONNECTED -> { val l = battLevel(); sys("chg", t("Charger dicabut", "Charger unplugged"), "$l%", l) }
                Intent.ACTION_BATTERY_LOW -> { val l = battLevel(); sys("chg", t("Baterai lemah", "Low battery"), "$l%", l) }
                Intent.ACTION_BATTERY_CHANGED -> pushBatt()
                AudioManager.RINGER_MODE_CHANGED_ACTION -> {
                    val m = (getSystemService(Context.AUDIO_SERVICE) as AudioManager).ringerMode
                    sys("mode", t("Mode suara", "Sound mode"), when (m) {
                        AudioManager.RINGER_MODE_SILENT -> t("Senyap", "Silent")
                        AudioManager.RINGER_MODE_VIBRATE -> t("Getar", "Vibrate")
                        else -> t("Dering", "Ring")
                    })
                }
                NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED -> {
                    val f = getSystemService(NotificationManager::class.java).currentInterruptionFilter
                    sys("mode", t("Jangan ganggu", "Do not disturb"),
                        if (f == NotificationManager.INTERRUPTION_FILTER_ALL) t("Mati", "Off") else t("Aktif", "On"))
                }
                WifiManager.WIFI_STATE_CHANGED_ACTION -> {
                    val st = i.getIntExtra(WifiManager.EXTRA_WIFI_STATE, -1)
                    if (st == WifiManager.WIFI_STATE_ENABLED) sys("mode", "Wi-Fi", on)
                    else if (st == WifiManager.WIFI_STATE_DISABLED) sys("mode", "Wi-Fi", off)
                }
                Intent.ACTION_AIRPLANE_MODE_CHANGED ->
                    sys("mode", t("Mode pesawat", "Airplane mode"),
                        if (i.getBooleanExtra("state", false)) t("Aktif", "On") else t("Mati", "Off"))
                "android.media.VOLUME_CHANGED_ACTION" -> {
                    val type = i.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1)
                    val v = i.getIntExtra("android.media.EXTRA_VOLUME_STREAM_VALUE", -1)
                    if (type == AudioManager.STREAM_MUSIC && v >= 0) {
                        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                        val mx = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                        val p = v * 100 / mx
                        sys("vol", "Volume", "$p%", p)
                    }
                }
            }
        }
    }

    private fun registerAll() {
        if (rcvOn) return
        val f = IntentFilter().apply {
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(Intent.ACTION_BATTERY_LOW)
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(AudioManager.RINGER_MODE_CHANGED_ACTION)
            addAction(NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED)
            addAction(WifiManager.WIFI_STATE_CHANGED_ACTION)
            addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED)
            addAction("android.media.VOLUME_CHANGED_ACTION")
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(rcv, f, Context.RECEIVER_EXPORTED)
        else registerReceiver(rcv, f)
        rcvOn = true
    }

    private fun parseMin(s: String): Int {
        val p = s.split(":")
        return (p.getOrNull(0)?.toIntOrNull() ?: 0) * 60 + (p.getOrNull(1)?.toIntOrNull() ?: 0)
    }

    private fun readConfig() {
        lang = cfg.optString("lang", "id")
        val set = HashSet<String>()
        val arr = cfg.optJSONObject("filter")?.optJSONArray("blocked")
        if (arr != null) for (k in 0 until arr.length()) set.add(arr.getString(k))
        blocked = set
        val qo = cfg.optJSONObject("quiet")
        quietOn = qo?.optBoolean("on", false) ?: false
        qFrom = parseMin(qo?.optString("from", "22:00") ?: "22:00")
        qTo = parseMin(qo?.optString("to", "06:00") ?: "06:00")
        hideLand = cfg.optJSONObject("hide")?.optBoolean("land", true) ?: true
    }

    /** Dipakai NotifListener: false jika aplikasi diblokir atau sedang jam senyap. */
    fun allowed(pkg: String): Boolean {
        if (blocked.contains(pkg)) return false
        if (quietOn) {
            val cal = Calendar.getInstance()
            val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
            val inQuiet = if (qFrom <= qTo) now in qFrom until qTo else (now >= qFrom || now < qTo)
            if (inQuiet) return false
        }
        return true
    }

    private fun applyVis() {
        main.post {
            val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
            val hide = !callActive && hideLand && land
            view?.visibility = if (hide) View.GONE else View.VISIBLE
        }
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        applyVis()
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        startFg()
        inst = this
        watcher = PrivacyWatcher(this, this).also { it.start() }
        main.postDelayed(battTick, 30000)
        registerAll()
        if (config == "{}") {
            config = getSharedPreferences("madz", MODE_PRIVATE).getString("cfg", "{}") ?: "{}"
        }
        cfg = try { JSONObject(config) } catch (e: Exception) { JSONObject() }
        readConfig()
        removeView()
        addView()
        return START_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ov", "Overlay", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "ov")
            .setContentTitle("MADZ aktif")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun addView() {
        d = resources.displayMetrics.density
        val L = cfg.optJSONObject("layout") ?: JSONObject()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val wv = WebView(this)
        wv.setBackgroundColor(Color.TRANSPARENT)
        wv.settings.javaScriptEnabled = true
        wv.addJavascriptInterface(OBridge(), "Android")
        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, u: String?) {
                v?.evaluateJavascript("setConfig(${JSONObject.quote(cfg.toString())})", null)
                pushBatt()
                NotifListener.inst?.refreshMusic()
            }
        }
        wv.loadUrl("file:///android_asset/overlay.html")
        val p = WindowManager.LayoutParams(
            ((L.optInt("w", 126) + 16) * d).toInt(), (52 * d).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        p.x = (L.optInt("x", 0) * d).toInt()
        p.y = ((L.optInt("y", 12) - 8).coerceAtLeast(0) * d).toInt()
        lp = p
        view = wv
        wm?.addView(wv, p)
        applyVis()
    }

    private fun removeView() {
        try { view?.let { wm?.removeView(it); it.destroy() } } catch (e: Exception) {}
        view = null
    }

    /* ---------- dipanggil NotifListener & MainActivity ---------- */
    fun notify(title: String, text: String, icon: String, hasKey: Boolean, canReply: Boolean, pkg: String = "", otp: String = "") =
        js("notify(${q(title)},${q(text)},${q(icon)},$hasKey,$canReply,${q(pkg)},${q(otp)})")

    fun vzPush(v: String) = js("vzData($v)")

    private fun lyrDir(): java.io.File {
        val d = java.io.File(filesDir, "lyrics")
        if (!d.exists()) d.mkdirs()
        return d
    }

    private fun lyrFile(key: String): java.io.File {
        val h = java.security.MessageDigest.getInstance("SHA-1").digest(key.lowercase().toByteArray())
        return java.io.File(lyrDir(), h.joinToString("") { "%02x".format(it) } + ".lrc")
    }

    private fun lyrSave(key: String, lrc: String) {
        try {
            val files = lyrDir().listFiles()
            if (files != null && files.size >= 300) {
                files.sortedBy { it.lastModified() }.take(files.size - 299).forEach { it.delete() }
            }
            lyrFile(key).writeText(lrc)
        } catch (e: Throwable) {}
    }

    fun rec(on: Boolean, start: Long) = js("rec($on,$start)")

    fun priv(kind: String, on: Boolean, app: String) = js("priv(${q(kind)},$on,${q(app)})")

    private fun lrcGet(u: String, list: Boolean = false): String {
        val c = java.net.URL(u).openConnection() as java.net.HttpURLConnection
        try {
            c.connectTimeout = 6000
            c.readTimeout = 6000
            c.setRequestProperty("User-Agent", "MADZ/1.0")
            if (c.responseCode != 200) return ""
            val body = c.inputStream.bufferedReader().readText()
            if (!list) {
                val s = org.json.JSONObject(body).optString("syncedLyrics", "")
                return if (s == "null") "" else s
            }
            val arr = org.json.JSONArray(body)
            for (i in 0 until arr.length()) {
                val s = arr.getJSONObject(i).optString("syncedLyrics", "")
                if (s.isNotEmpty() && s != "null") return s
            }
            return ""
        } finally {
            c.disconnect()
        }
    }

    fun call(name: String, state: String, icon: String) {
        callActive = true
        applyVis()
        js("callShow(${q(name)},${q(state)},${q(icon)})")
    }

    fun alarm(title: String, text: String) {
        callActive = true
        applyVis()
        js("alarmShow(${q(title)},${q(text)})")
    }

    fun callEnd() {
        callActive = false
        applyVis()
        js("callEnd()")
    }

    fun nav(t: String, s: String) = js("navShow(${q(t)},${q(s)})")
    fun navEnd() = js("navEnd()")
    fun progress(t: String, s: String, pct: Int) = js("progShow(${q(t)},${q(s)},$pct)")
    fun progEnd() = js("progEnd()")
    fun liveCmd(json: String) = js("liveCmd(${q(json)})")

    fun setMusic(t: String, a: String, art: String, playing: Boolean, pos: Long, dur: Long, color: String) =
        js("setMusic(${q(t)},${q(a)},${q(art)},$playing,$pos,$dur,${q(color)})")

    fun stopMusic() = js("stopMusic()")

    override fun onDestroy() {
        try { unregisterReceiver(rcv) } catch (e: Exception) {}
        rcvOn = false
        removeView()
        watcher?.stop()
        watcher = null
        main.removeCallbacks(battTick)
        audioViz?.stop()
        audioViz = null
        inst = null
        super.onDestroy()
    }

    inner class OBridge {
        @JavascriptInterface
        fun resize(open: Boolean, w: Int) {
            main.post {
                val L = cfg.optJSONObject("layout") ?: JSONObject()
                val sw = resources.displayMetrics.widthPixels
                val p = lp ?: return@post
                if (open) {
                    p.width = minOf(((L.optInt("e", 320) + 16) * d).toInt(), sw)
                    p.height = (100 * d).toInt()
                } else {
                    p.width = (w * d).toInt()
                    p.height = (52 * d).toInt()
                }
                try { view?.let { wm?.updateViewLayout(it, p) } } catch (e: Exception) {}
            }
        }

        @JavascriptInterface
        fun media(cmd: String) { NotifListener.inst?.mediaCmd(cmd) }

        @JavascriptInterface
        fun vzCtl(on: Boolean) {
            main.post {
                if (on && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    if (audioViz == null) audioViz = AudioViz(this@OverlayService)
                    audioViz?.start()
                } else {
                    audioViz?.stop()
                }
            }
        }

        @JavascriptInterface
        fun copyOtp(t: String) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            val clip = android.content.ClipData.newPlainText("kode", t)
            try {
                val x = android.os.PersistableBundle()
                x.putBoolean("android.content.extra.IS_SENSITIVE", true)
                clip.description.extras = x
            } catch (e: Throwable) {}
            cm.setPrimaryClip(clip)
        }

        @JavascriptInterface
        fun lyrics(artist: String, title: String, durMs: Long) {
            val key = "$title|$artist"
            val cf = lyrFile(key)
            if (cf.exists()) {
                val cached = try { cf.readText() } catch (e: Throwable) { "" }
                if (cached.isNotEmpty()) {
                    cf.setLastModified(System.currentTimeMillis())
                    js("lyrSet(${q(key)},${q(cached)})")
                    return
                }
            }
            Thread {
                var lrc = ""
                try {
                    val a = java.net.URLEncoder.encode(artist, "UTF-8")
                    val t = java.net.URLEncoder.encode(title, "UTF-8")
                    val d = if (durMs > 0) "&duration=${durMs / 1000}" else ""
                    lrc = lrcGet("https://lrclib.net/api/get?artist_name=$a&track_name=$t$d")
                    if (lrc.isEmpty()) lrc = lrcGet("https://lrclib.net/api/search?artist_name=$a&track_name=$t", true)
                } catch (e: Throwable) {}
                if (lrc.isNotEmpty()) lyrSave(key, lrc)
                js("lyrSet(${q(key)},${q(lrc)})")
            }.start()
        }

        @JavascriptInterface
        fun haptic(k: Int) {
            main.post {
                view?.performHapticFeedback(
                    if (k == 1) HapticFeedbackConstants.LONG_PRESS else HapticFeedbackConstants.CLOCK_TICK
                )
            }
        }

        @JavascriptInterface
        fun notifOpen() { NotifListener.inst?.openLast() }

        @JavascriptInterface
        fun openApp() {
            val i = packageManager.getLaunchIntentForPackage(packageName) ?: return
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        }

        @JavascriptInterface
        fun notifDismiss() { NotifListener.inst?.dismissLast() }

        @JavascriptInterface
        fun callAction(kind: String) { NotifListener.inst?.callAction(kind) }

        @JavascriptInterface
        fun reply(text: String) { NotifListener.inst?.reply(text) }
    }
}
