package com.madz.web

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.AudioRecordingConfiguration
import android.os.Handler
import android.os.Looper
import android.os.Process

/** Mengawasi kamera & mikrofon yang sedang dipakai aplikasi lain. */
class PrivacyWatcher(private val ctx: Context, private val svc: OverlayService) {
    private val main = Handler(Looper.getMainLooper())
    private val busy = HashSet<String>()
    private var camOn = false
    private var micOn = false
    private var started = false

    private val camCb = object : CameraManager.AvailabilityCallback() {
        override fun onCameraUnavailable(cameraId: String) { busy.add(cameraId); camUpdate() }
        override fun onCameraAvailable(cameraId: String) { busy.remove(cameraId); camUpdate() }
    }

    private val micCb = object : AudioManager.AudioRecordingCallback() {
        override fun onRecordingConfigChanged(configs: MutableList<AudioRecordingConfiguration>?) {
            micUpdate(!configs.isNullOrEmpty())
        }
    }

    fun start() {
        if (started) return
        started = true
        try {
            (ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager)
                .registerAvailabilityCallback(camCb, main)
        } catch (e: Throwable) {}
        try {
            (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager)
                .registerAudioRecordingCallback(micCb, main)
        } catch (e: Throwable) {}
    }

    fun stop() {
        if (!started) return
        started = false
        try {
            (ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager)
                .unregisterAvailabilityCallback(camCb)
        } catch (e: Throwable) {}
        try {
            (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager)
                .unregisterAudioRecordingCallback(micCb)
        } catch (e: Throwable) {}
    }

    private fun camUpdate() {
        val on = busy.isNotEmpty()
        if (on == camOn) return
        camOn = on
        svc.priv("cam", on, if (on) fgApp() else "")
    }

    private fun micUpdate(on: Boolean) {
        if (on == micOn) return
        micOn = on
        svc.priv("mic", on, if (on) fgApp() else "")
    }

    /** Perkiraan nama aplikasi: aplikasi yang terakhir dibuka di depan. Butuh akses data penggunaan. */
    private fun fgApp(): String {
        try {
            val ao = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = ao.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
            if (mode != AppOpsManager.MODE_ALLOWED) return ""
            val um = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val ev = um.queryEvents(now - 2 * 3600_000L, now)
            val e = UsageEvents.Event()
            var pkg = ""
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                if (e.eventType == 1) pkg = e.packageName
            }
            if (pkg.isEmpty() || pkg == ctx.packageName) return ""
            if (pkg.contains("launcher") || pkg.contains("systemui")) return ""
            val pm = ctx.packageManager
            return pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (t: Throwable) {
            return ""
        }
    }
}
