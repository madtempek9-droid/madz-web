package com.madz.web

import android.util.Log
import android.media.audiofx.Visualizer
import kotlin.math.hypot
import kotlin.math.sqrt

/** Membaca spektrum suara keluaran (bukan merekam) dan mengirim 7 pita ke island. */
class AudioViz(private val svc: OverlayService) {
    private var vis: Visualizer? = null
    private val edges = intArrayOf(1, 2, 4, 8, 16, 32, 64, 128)

    fun start() {
        if (vis != null) return
        try {
            val v = Visualizer(0)
            val r = Visualizer.getCaptureSizeRange()
            v.captureSize = if (512 in r[0]..r[1]) 512 else r[1]
            val rate = minOf(Visualizer.getMaxCaptureRate(), 15000)
            v.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(vz: Visualizer?, waveform: ByteArray?, samplingRate: Int) {}
                override fun onFftDataCapture(vz: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                    if (fft != null) push(fft)
                }
            }, rate, false, true)
            v.enabled = true
            vis = v
        } catch (e: Throwable) {
            try { vis?.release() } catch (x: Throwable) {}
            vis = null
        }
    }

    fun stop() {
        try {
            vis?.enabled = false
            vis?.release()
        } catch (e: Throwable) { Log.w("MADZ", "AudioViz", e) }
        vis = null
    }

    private fun push(fft: ByteArray) {
        val nb = fft.size / 2
        val sc = nb / 256f
        val sb = StringBuilder("[")
        for (b in 0 until 7) {
            val s = maxOf(1, (edges[b] * sc).toInt())
            val e = minOf(nb, maxOf(s + 1, (edges[b + 1] * sc).toInt()))
            var m = 0.0
            for (k in s until e) {
                val re = fft[2 * k].toInt()
                val im = fft[2 * k + 1].toInt()
                m = maxOf(m, hypot(re.toDouble(), im.toDouble()))
            }
            val v = (sqrt(m / 90.0) * 100).toInt().coerceIn(0, 100)
            if (b > 0) sb.append(',')
            sb.append(v)
        }
        sb.append(']')
        svc.vzPush(sb.toString())
    }
}
