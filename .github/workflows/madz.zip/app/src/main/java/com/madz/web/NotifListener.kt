package com.madz.web

import android.app.Notification
import android.app.RemoteInput
import android.content.ComponentName
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Base64
import java.io.ByteArrayOutputStream

class NotifListener : NotificationListenerService() {
    companion object { var inst: NotifListener? = null }

    private var controllers: List<MediaController> = emptyList()
    private var active: MediaController? = null
    private var lastSbn: StatusBarNotification? = null
    private var lastCall: StatusBarNotification? = null
    private var lastAlarm: StatusBarNotification? = null
    private var progKey: String? = null

    private val cb = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) { refreshMusic() }
        override fun onMetadataChanged(metadata: MediaMetadata?) { refreshMusic() }
    }
    private val sessionListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> attach(list ?: emptyList()) }

    override fun onListenerConnected() {
        inst = this
        try {
            val msm = getSystemService(MediaSessionManager::class.java)
            val comp = ComponentName(this, NotifListener::class.java)
            msm.addOnActiveSessionsChangedListener(sessionListener, comp)
            attach(msm.getActiveSessions(comp))
        } catch (e: Exception) {}
    }

    override fun onListenerDisconnected() {
        try {
            getSystemService(MediaSessionManager::class.java).removeOnActiveSessionsChangedListener(sessionListener)
            controllers.forEach { it.unregisterCallback(cb) }
        } catch (e: Exception) {}
        controllers = emptyList()
        active = null
        inst = null
    }

    private fun attach(list: List<MediaController>) {
        try { controllers.forEach { it.unregisterCallback(cb) } } catch (e: Exception) {}
        controllers = list
        list.forEach { try { it.registerCallback(cb) } catch (e: Exception) {} }
        refreshMusic()
    }

    /* ---------- musik ---------- */
    fun mediaCmd(cmd: String) {
        val t = (active ?: return).transportControls
        when (cmd) {
            "play" -> t.play()
            "pause" -> t.pause()
            "next" -> t.skipToNext()
            "prev" -> t.skipToPrevious()
        }
    }

    fun refreshMusic() {
        val svc = OverlayService.inst ?: return
        val playing = controllers.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
        val c = playing ?: controllers.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PAUSED }
        active = c
        val m = c?.metadata
        val title = m?.getString(MediaMetadata.METADATA_KEY_TITLE)
        if (c == null || title.isNullOrEmpty()) { svc.stopMusic(); return }
        val artist = m.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        val bmp = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: m.getBitmap(MediaMetadata.METADATA_KEY_ART)
        var art = ""
        var color = ""
        if (bmp != null) {
            val sm = Bitmap.createScaledBitmap(bmp, 96, 96, true)
            val o = ByteArrayOutputStream()
            sm.compress(Bitmap.CompressFormat.JPEG, 80, o)
            art = "data:image/jpeg;base64," + Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
            val px = Bitmap.createScaledBitmap(bmp, 1, 1, true).getPixel(0, 0)
            val hsv = FloatArray(3)
            Color.colorToHSV(px, hsv)
            hsv[1] = minOf(1f, hsv[1] * 1.2f)
            hsv[2] = maxOf(hsv[2], 0.85f)
            color = String.format("#%06X", 0xFFFFFF and Color.HSVToColor(hsv))
        }
        val pos = c.playbackState?.position ?: 0L
        val dur = m.getLong(MediaMetadata.METADATA_KEY_DURATION)
        svc.setMusic(title, artist, art, playing != null, pos, dur, color)
    }

    /* ---------- ikon ---------- */
    private fun dataUrl(d: Drawable?): String {
        if (d == null) return ""
        return try {
            val bmp = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
            d.setBounds(0, 0, 96, 96)
            d.draw(Canvas(bmp))
            val o = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.PNG, 100, o)
            "data:image/png;base64," + Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
        } catch (e: Exception) { "" }
    }

    private fun iconOf(sbn: StatusBarNotification): String {
        val large = try { sbn.notification.getLargeIcon()?.loadDrawable(this) } catch (e: Exception) { null }
        val d = large ?: try { packageManager.getApplicationIcon(sbn.packageName) } catch (e: Exception) { null }
        return dataUrl(d)
    }

    /* ---------- notifikasi, telepon, alarm, progres, navigasi ---------- */
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification
        val e = n.extras
        val title = e.getCharSequence("android.title")?.toString() ?: ""
        val text = e.getCharSequence("android.text")?.toString() ?: ""
        val svc = OverlayService.inst ?: return

        if (n.category == Notification.CATEGORY_ALARM &&
            (n.fullScreenIntent != null || (n.flags and Notification.FLAG_INSISTENT) != 0)
        ) {
            lastAlarm = sbn
            svc.alarm(title, text)
            return
        }
        if (n.category == Notification.CATEGORY_CALL) {
            lastCall = sbn
            val ongoing = e.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER, false)
            svc.call(title.ifEmpty { "Telepon" }, if (ongoing) "ongoing" else "in", iconOf(sbn))
            return
        }
        if (sbn.packageName == "com.google.android.apps.maps" && sbn.isOngoing) {
            svc.nav(title, text)
            return
        }
        val max = e.getInt(Notification.EXTRA_PROGRESS_MAX, 0)
        if (max > 0 && !e.getBoolean(Notification.EXTRA_PROGRESS_INDETERMINATE, false)) {
            if (!svc.allowed(sbn.packageName)) return
            val pct = (e.getInt(Notification.EXTRA_PROGRESS, 0) * 100 / max).coerceIn(0, 100)
            progKey = sbn.key
            svc.progress(title, text, pct)
            return
        }
        if (sbn.isOngoing || title.isEmpty()) return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if (!svc.allowed(sbn.packageName)) return
        lastSbn = sbn
        val canReply = n.actions?.any { a -> a.remoteInputs?.isNotEmpty() == true } == true
        svc.notify(title, text, iconOf(sbn), true, canReply, sbn.packageName)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        val svc = OverlayService.inst ?: return
        val cat = sbn.notification.category
        if (cat == Notification.CATEGORY_CALL) {
            lastCall = null
            svc.callEnd()
        } else if (cat == Notification.CATEGORY_ALARM && sbn.key == lastAlarm?.key) {
            lastAlarm = null
            svc.callEnd()
        } else if (sbn.packageName == "com.google.android.apps.maps") {
            svc.navEnd()
        } else if (sbn.key == progKey) {
            progKey = null
            svc.progEnd()
        }
    }

    fun openLast() {
        try { lastSbn?.notification?.contentIntent?.send() } catch (e: Exception) {}
    }

    fun dismissLast() {
        lastSbn?.let { try { cancelNotification(it.key) } catch (e: Exception) {} }
    }

    fun reply(text: String) {
        val acts = lastSbn?.notification?.actions ?: return
        val act = acts.firstOrNull { a -> a.remoteInputs?.isNotEmpty() == true } ?: return
        val inputs = act.remoteInputs ?: return
        val intent = Intent()
        val bundle = Bundle()
        bundle.putCharSequence(inputs[0].resultKey, text)
        RemoteInput.addResultsToIntent(inputs, intent, bundle)
        try { act.actionIntent.send(this, 0, intent) } catch (e: Exception) {}
    }

    fun callAction(kind: String) {
        val isAlarm = kind == "snooze" || kind == "dismiss"
        val acts = (if (isAlarm) lastAlarm else lastCall)?.notification?.actions ?: return
        val rx = when (kind) {
            "answer" -> Regex("answer|jawab|terima|accept", RegexOption.IGNORE_CASE)
            "decline" -> Regex("decline|tolak|reject|dismiss", RegexOption.IGNORE_CASE)
            "snooze" -> Regex("snooze|tunda|ulangi", RegexOption.IGNORE_CASE)
            "dismiss" -> Regex("dismiss|matikan|stop|off|hentikan", RegexOption.IGNORE_CASE)
            else -> Regex("hang|akhiri|end|tutup", RegexOption.IGNORE_CASE)
        }
        val a = acts.firstOrNull { rx.containsMatchIn(it.title) }
            ?: if (kind == "answer" || kind == "dismiss") acts.lastOrNull() else acts.firstOrNull()
        try { a?.actionIntent?.send() } catch (e: Exception) {}
    }
}
