package com.madz.web

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName || sbn.isOngoing) return
        val e = sbn.notification.extras
        val t = e.getCharSequence("android.title")?.toString() ?: return
        val s = e.getCharSequence("android.text")?.toString() ?: ""
        OverlayService.inst?.notify(t, s)
    }
}
