package com.madz.web

import android.content.ComponentName
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Base64
import java.io.ByteArrayOutputStream

class NotifListener : NotificationListenerService() {
    companion object { var inst: NotifListener? = null }

    private var controllers: List<MediaController> = emptyList()
    private val cb = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) { refreshMusic() }
        override fun onMetadataChanged(metadata: MediaMetadata?) { refreshMusic() }
    }
    private val sessionListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> attach(list ?: emptyList()) }

    override fun onListenerConnected() {
        inst = this
        try {
            val msm = getSystemService(MediaSessionManager::class.java)
            val comp = ComponentName(this, NotifListener::class.java)
            msm.addOnActiveSessionsChangedListener(sessionListener, comp)
            attach(msm.getActiveSessions(comp))
        } catch (e: Exception) {}
    }

    override fun onListenerDisconnected() {
        try {
            getSystemService(MediaSessionManager::class.java).removeOnActiveSessionsChangedListener(sessionListener)
            controllers.forEach { it.unregisterCallback(cb) }
        } catch (e: Exception) {}
        controllers = emptyList()
        inst = null
    }

    private fun attach(list: List<MediaController>) {
        try { controllers.forEach { it.unregisterCallback(cb) } } catch (e: Exception) {}
        controllers = list
        list.forEach { try { it.registerCallback(cb) } catch (e: Exception) {} }
        refreshMusic()
    }

    fun refreshMusic() {
        val svc = OverlayService.inst ?: return
        val c = controllers.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
        val m = c?.metadata
        val title = m?.getString(MediaMetadata.METADATA_KEY_TITLE)
        if (c == null || title.isNullOrEmpty()) { svc.stopMusic(); return }
        val artist = m.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        val bmp = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: m.getBitmap(MediaMetadata.METADATA_KEY_ART)
        var art = ""
        if (bmp != null) {
            val sm = Bitmap.createScaledBitmap(bmp, 96, 96, true)
            val o = ByteArrayOutputStream()
            sm.compress(Bitmap.CompressFormat.JPEG, 80, o)
            art = "data:image/jpeg;base64," + Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
        }
        svc.setMusic(title, artist, art)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName || sbn.isOngoing) return
        val e = sbn.notification.extras
        val t = e.getCharSequence("android.title")?.toString() ?: return
        val s = e.getCharSequence("android.text")?.toString() ?: ""
        OverlayService.inst?.notify(t, s)
    }
}
