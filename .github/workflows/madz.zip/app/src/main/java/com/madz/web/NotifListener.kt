package com.madz.web

import android.app.Notification
import android.content.ComponentName
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Base64
import java.io.ByteArrayOutputStream

class NotifListener : NotificationListenerService() {
    companion object { var inst: NotifListener? = null }

    private var controllers: List<MediaController> = emptyList()
    private var active: MediaController? = null
    private var lastSbn: StatusBarNotification? = null
    private var lastCall: StatusBarNotification? = null

    private val cb = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) { refreshMusic() }
        override fun onMetadataChanged(metadata: MediaMetadata?) { refreshMusic() }
    }
    private val sessionListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> attach(list ?: emptyList()) }

    override fun onListenerConnected() {
        inst = this
        try {
            val msm = getSystemService(MediaSessionManager::class.java)
            val comp = ComponentName(this, NotifListener::class.java)
            msm.addOnActiveSessionsChangedListener(sessionListener, comp)
            attach(msm.getActiveSessions(comp))
        } catch (e: Exception) {}
    }

    override fun onListenerDisconnected() {
        try {
            getSystemService(MediaSessionManager::class.java).removeOnActiveSessionsChangedListener(sessionListener)
            controllers.forEach { it.unregisterCallback(cb) }
        } catch (e: Exception) {}
        controllers = emptyList()
        active = null
        inst = null
    }

    private fun attach(list: List<MediaController>) {
        try { controllers.forEach { it.unregisterCallback(cb) } } catch (e: Exception) {}
        controllers = list
        list.forEach { try { it.registerCallback(cb) } catch (e: Exception) {} }
        refreshMusic()
    }

    /* ---------- musik ---------- */
    fun mediaCmd(cmd: String) {
        val t = (active ?: return).transportControls
        when (cmd) {
            "play" -> t.play()
            "pause" -> t.pause()
            "next" -> t.skipToNext()
            "prev" -> t.skipToPrevious()
        }
    }

    fun refreshMusic() {
        val svc = OverlayService.inst ?: return
        val playing = controllers.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
        val c = playing ?: controllers.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PAUSED }
        active = c
        val m = c?.metadata
        val title = m?.getString(MediaMetadata.METADATA_KEY_TITLE)
        if (c == null || title.isNullOrEmpty()) { svc.stopMusic(); return }
        val artist = m.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        val bmp = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: m.getBitmap(MediaMetadata.METADATA_KEY_ART)
        var art = ""
        var color = ""
        if (bmp != null) {
            val sm = Bitmap.createScaledBitmap(bmp, 96, 96, true)
            val o = ByteArrayOutputStream()
            sm.compress(Bitmap.CompressFormat.JPEG, 80, o)
            art = "data:image/jpeg;base64," + Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
            val px = Bitmap.createScaledBitmap(bmp, 1, 1, true).getPixel(0, 0)
            val hsv = FloatArray(3)
            Color.colorToHSV(px, hsv)
            hsv[1] = minOf(1f, hsv[1] * 1.2f)
            hsv[2] = maxOf(hsv[2], 0.85f)
            color = String.format("#%06X", 0xFFFFFF and Color.HSVToColor(hsv))
        }
        val pos = c.playbackState?.position ?: 0L
        val dur = m.getLong(MediaMetadata.METADATA_KEY_DURATION)
        svc.setMusic(title, artist, art, playing != null, pos, dur, color)
    }

    /* ---------- ikon ---------- */
    private fun dataUrl(d: Drawable?): String {
        if (d == null) return ""
        return try {
            val bmp = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
            d.setBounds(0, 0, 96, 96)
            d.draw(Canvas(bmp))
            val o = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.PNG, 100, o)
            "data:image/png;base64," + Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
        } catch (e: Exception) { "" }
    }

    private fun iconOf(sbn: StatusBarNotification): String {
        val large = try { sbn.notification.getLargeIcon()?.loadDrawable(this) } catch (e: Exception) { null }
        val d = large ?: try { packageManager.getApplicationIcon(sbn.packageName) } catch (e: Exception) { null }
        return dataUrl(d)
    }

    /* ---------- notifikasi, telepon, navigasi ---------- */
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification
        val e = n.extras
        val title = e.getCharSequence("android.title")?.toString() ?: ""
        val text = e.getCharSequence("android.text")?.toString() ?: ""
        val svc = OverlayService.inst ?: return

        if (n.category == Notification.CATEGORY_CALL) {
            lastCall = sbn
            val ongoing = e.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER, false)
            svc.call(title.ifEmpty { "Telepon" }, if (ongoing) "ongoing" else "in", iconOf(sbn))
            return
        }
        if (sbn.packageName == "com.google.android.apps.maps" && sbn.isOngoing) {
            svc.nav(title, text)
            return
        }
        if (sbn.isOngoing || title.isEmpty()) return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        lastSbn = sbn
        svc.notify(title, text, iconOf(sbn), true)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        val svc = OverlayService.inst ?: return
        if (sbn.notification.category == Notification.CATEGORY_CALL) {
            lastCall = null
            svc.callEnd()
        } else if (sbn.packageName == "com.google.android.apps.maps") {
            svc.navEnd()
        }
    }

    fun openLast() {
        try { lastSbn?.notification?.contentIntent?.send() } catch (e: Exception) {}
    }

    fun dismissLast() {
        lastSbn?.let { try { cancelNotification(it.key) } catch (e: Exception) {} }
    }

    fun callAction(kind: String) {
        val acts = lastCall?.notification?.actions ?: return
        val rx = when (kind) {
            "answer" -> Regex("answer|jawab|terima|accept", RegexOption.IGNORE_CASE)
            "decline" -> Regex("decline|tolak|reject|dismiss", RegexOption.IGNORE_CASE)
            else -> Regex("hang|akhiri|end|tutup", RegexOption.IGNORE_CASE)
        }
        val a = acts.firstOrNull { rx.containsMatchIn(it.title) }
            ?: if (kind == "answer") acts.lastOrNull() else acts.firstOrNull()
        try { a?.actionIntent?.send() } catch (e: Exception) {}
    }
}
